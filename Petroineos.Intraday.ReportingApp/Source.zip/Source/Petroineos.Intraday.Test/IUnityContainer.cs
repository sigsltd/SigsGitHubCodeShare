﻿namespace Petroineos.Intraday.Test
{
    internal interface IUnityContainer
    {
    }
}