﻿namespace Petroineos.Intraday.Lib.Model
{
    public class PowerIntraDayReport
    {
        public string ReportFilename { get; set; }
    }
}